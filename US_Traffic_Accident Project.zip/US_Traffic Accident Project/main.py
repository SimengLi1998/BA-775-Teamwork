# -*- coding: utf-8 -*-

import pickle
from common import *
from sklearn import svm, neural_network, linear_model, naive_bayes, neighbors, tree, ensemble, metrics


def process_file(filename):
    conts, labs = [], []
    with open_file(filename) as f_:
        for line in f_:
            cs = line.strip().split("\t")
            conts.append(cs[:-1])
            labs.append(cs[-1])
    print(np.array(conts).shape)
    return np.array(conts).astype("float"), np.array(labs).astype("int").tolist()


def train(train_dir):
    train_feature, train_target = process_file(train_dir)
    print(np.array(train_feature).shape)
    print(np.array(train_target).shape)

    # train
    print("training...")
    model.fit(train_feature, train_target)


def test():
    test_feature, test_target = process_file("data/ft.test.txt")
    test_predict = model.predict(test_feature)  # return predict classification
    # test_predict_proba = model.predict_proba(test_feature)  # 返回属于各个类别的概率
    # test_predict = np.argmax(test_predict_proba, 1)  # 返回概率最大的类别标签

    # accuracy
    true_false = (test_predict == test_target)
    accuracy = np.count_nonzero(true_false) / float(len(test_target))
    print()
    print("accuracy is %f" % accuracy)

    # precision    recall  f1-score
    print()
    print(metrics.classification_report(test_target, test_predict))

    # Confusion Matrix
    print("Confusion Matrix...")
    print(metrics.confusion_matrix(test_target, test_predict))


# random forest
# model = ensemble.RandomForestClassifier()


# logistic regression
# model = linear_model.LogisticRegression(multi_class="multinomial", solver="lbfgs")

# SVM
# model = svm.LinearSVC()

# neural network
model = neural_network.MLPClassifier(hidden_layer_sizes=(2048, 512), verbose=True, early_stopping=True)



train("data/ft.train.txt")
# print(model.feature_importances_)  # only work for none one-hot and random forest

test()
