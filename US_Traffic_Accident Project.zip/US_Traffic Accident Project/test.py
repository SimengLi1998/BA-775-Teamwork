# -*- coding: utf-8 -*-

import numpy as np

# one-hot-try
def to_categorical(y, num_classes=None):
    y = np.array(y, dtype='int')
    input_shape = y.shape
    if input_shape and input_shape[-1] == 1 and len(input_shape) > 1:
        input_shape = tuple(input_shape[:-1])
    y = y.ravel()
    if not num_classes:
        num_classes = np.max(y) + 1
    n = y.shape[0]
    categorical = np.zeros((n, num_classes))
    categorical[np.arange(n), y] = 1
    output_shape = input_shape + (num_classes,)
    categorical = np.reshape(categorical, output_shape)
    return categorical.tolist()


print(to_categorical(2, 5))

# (id,cnt)




features = ["State", "Month", "Hour", "Weekday", "Weather", "Visibility", "Preciputation", "Windspead", "Temperature",
            "Junction", "Crossing", "Traffic_Signal"]

[0.24576095 0.1161777  0.11244845 0.07363488 0.06306923 0.03782972
 0.02310259 0.10666823 0.14400373 0.01721316 0.0270967  0.03299465]

